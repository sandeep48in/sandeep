import React, { useState, useEffect, useMemo } from 'react';
import { Transaction, AppConfig, TransactionType } from './types';
import { SimpleEntry } from './components/SimpleEntry';
import { fetchTransactions, sendTransaction, undoTransaction, loadCachedTransactions, saveCachedTransactions } from './services/sheetService';
import { Settings as SettingsIcon, RefreshCw, ArrowDownCircle, ArrowUpCircle, Calendar as CalendarIcon, Wallet, BarChart3, List, Search, X, ChevronLeft, ChevronRight, Plus, Minus, AlertTriangle, Lock, Eye, RotateCcw, Sparkles, Undo2, CheckCircle } from 'lucide-react';
import { Settings } from './components/Settings';
import { Dashboard } from './components/Dashboard';
import { CalendarView } from './components/CalendarView';
import { ChatWindow } from './components/ChatWindow';

type ViewMode = 'LIST' | 'CHART' | 'CALENDAR';

const App: React.FC = () => {
  const [history, setHistory] = useState<Transaction[]>([]);
  const [activeEntryType, setActiveEntryType] = useState<TransactionType | null>(null);
  const [loading, setLoading] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [viewMode, setViewMode] = useState<ViewMode>('LIST');
  const [searchQuery, setSearchQuery] = useState('');
  const [showTotalBalance, setShowTotalBalance] = useState(false);
  const [lastAddedTxId, setLastAddedTxId] = useState<string | null>(null);
  const [showUndoToast, setShowUndoToast] = useState(false);
  const [cutoffDate, setCutoffDate] = useState<string | null>(() => localStorage.getItem('expense_cutoff_date'));
  const [currentDate, setCurrentDate] = useState(() => {
    try {
        const cached = loadCachedTransactions();
        if (cached && cached.length > 0) {
            const dates = cached.map(t => new Date(t.date).getTime());
            const maxDate = new Date(Math.max(...dates));
            if (!isNaN(maxDate.getTime())) return maxDate;
        }
    } catch(e) {}
    return new Date();
  });
  const [config, setConfig] = useState<AppConfig>(() => {
    const saved = localStorage.getItem('sheet_config');
    return saved ? JSON.parse(saved) : { sheetUrl: '', isConfigured: false };
  });

  useEffect(() => { loadHistory(); }, [config]);
  useEffect(() => {
    if (showUndoToast) {
        const timer = setTimeout(() => { setShowUndoToast(false); setLastAddedTxId(null); }, 8000);
        return () => clearTimeout(timer);
    }
  }, [showUndoToast]);

  const loadHistory = async () => {
    setLoading(true);
    const cached = loadCachedTransactions();
    if (cached.length > 0) setHistory(cached);
    const data = await fetchTransactions(config);
    if (data) {
      setHistory(data);
      saveCachedTransactions(data);
      if (data.length > 0 && history.length === 0) {
          const dates = data.map(t => new Date(t.date).getTime());
          const maxDate = new Date(Math.max(...dates));
          if (!isNaN(maxDate.getTime())) setCurrentDate(maxDate);
      }
    }
    setLoading(false);
  };

  const handleSaveConfig = (newConfig: AppConfig) => {
    setConfig(newConfig);
    localStorage.setItem('sheet_config', JSON.stringify(newConfig));
    setShowSettings(false);
    setTimeout(() => loadHistory(), 500);
  };
  
  const handleDataCleared = () => {
      setHistory([]);
      saveCachedTransactions([]);
      loadHistory();
      setShowSettings(false);
  };

  const handleSoftReset = () => {
      const newCutoff = new Date().toISOString();
      setCutoffDate(newCutoff);
      localStorage.setItem('expense_cutoff_date', newCutoff);
      setCurrentDate(new Date());
  };

  const handleUndoReset = () => {
      setCutoffDate(null);
      localStorage.removeItem('expense_cutoff_date');
  };

  const handleSubmitTransaction = async (data: { type: TransactionType; amount: number; category: string; description?: string }) => {
    const tempId = Math.random().toString(36).substring(7);
    const offset = new Date().getTimezoneOffset() * 60000;
    const localDateStr = (new Date(new Date().getTime() - offset)).toISOString().slice(0, -1);
    
    const newTx: Transaction = {
      id: tempId,
      ...data,
      description: data.description || `${data.type === 'CREDIT' ? 'Credit' : 'Debit'} of ${data.amount} for ${data.category}`,
      date: localDateStr 
    };

    const updatedHistory = [newTx, ...history];
    setHistory(updatedHistory);
    saveCachedTransactions(updatedHistory);
    setLastAddedTxId(tempId);
    setShowUndoToast(true);

    const txDate = new Date(newTx.date);
    if (txDate.getMonth() !== currentDate.getMonth() || txDate.getFullYear() !== currentDate.getFullYear()) {
        setCurrentDate(txDate);
    }

    if (config.isConfigured) {
        sendTransaction(config, { ...data, id: tempId });
    }
  };

  const handleUndoLastTransaction = async () => {
      if (!lastAddedTxId) return;
      const prevHistory = [...history];
      const updatedHistory = history.filter(tx => tx.id !== lastAddedTxId);
      setHistory(updatedHistory);
      saveCachedTransactions(updatedHistory);
      setShowUndoToast(false);
      setLastAddedTxId(null);
      if (config.isConfigured) {
          const success = await undoTransaction(config, lastAddedTxId);
          if (!success) { alert("Failed to undo on server."); setHistory(prevHistory); }
      }
  };

  const validHistory = useMemo(() => {
      if (!cutoffDate) return history;
      return history.filter(tx => new Date(tx.date) > new Date(cutoffDate));
  }, [history, cutoffDate]);

  const selectedMonthStr = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}`;

  const filteredHistory = useMemo(() => {
    let filtered = validHistory.filter(tx => tx.date.startsWith(selectedMonthStr));
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter(tx => 
        tx.description.toLowerCase().includes(q) || 
        tx.category.toLowerCase().includes(q) ||
        tx.amount.toString().includes(q)
      );
    }
    return filtered;
  }, [validHistory, selectedMonthStr, searchQuery]);

  const monthlyStats = useMemo(() => {
    let income = 0; let expense = 0;
    filteredHistory.forEach(tx => { if (tx.type === 'CREDIT') income += tx.amount; else expense += tx.amount; });
    return { income, expense };
  }, [filteredHistory]);

  const totalBalance = useMemo(() => {
    return validHistory.reduce((acc, tx) => acc + (tx.type === 'CREDIT' ? tx.amount : -tx.amount), 0);
  }, [validHistory]);

  const changeMonth = (delta: number) => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + delta, 1));
  };

  const [selectedCalendarDate, setSelectedCalendarDate] = useState<Date | null>(null);
  const calendarDayTransactions = useMemo(() => {
    if (!selectedCalendarDate) return [];
    const dateStr = selectedCalendarDate.toISOString().split('T')[0];
    return validHistory.filter(tx => tx.date.startsWith(dateStr));
  }, [selectedCalendarDate, validHistory]);

  return (
    <div className="h-screen flex flex-col font-sans selection:bg-indigo-500 selection:text-white bg-gray-950">
      <header className="glass-panel border-b border-gray-800 sticky top-0 z-20">
        <div className="px-6 py-4">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl shadow-lg shadow-indigo-500/20"><Wallet size={22} className="text-white" /></div>
              <div><h1 className="text-xl font-bold text-white tracking-tight leading-none">Expense Hub</h1>
                  <p className="text-xs text-gray-400 mt-1 font-medium flex items-center gap-1">
                      {config.isConfigured ? <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span> : <span className="w-2 h-2 rounded-full bg-amber-500"></span>}
                      {config.isConfigured ? 'Connected' : 'Demo Mode'}
                  </p>
              </div>
            </div>
            <div className="flex gap-2">
                {cutoffDate && (<button onClick={handleUndoReset} className="p-2.5 text-amber-500 bg-amber-900/20 hover:bg-amber-900/30 rounded-xl" title="Undo Start Fresh"><RotateCcw size={20} /></button>)}
                <button onClick={loadHistory} className="p-2.5 text-gray-400 hover:text-white hover:bg-gray-800 rounded-xl"><RefreshCw size={20} className={loading ? 'animate-spin' : ''} /></button>
                <button onClick={() => setShowSettings(true)} className="p-2.5 text-gray-400 hover:text-white hover:bg-gray-800 rounded-xl"><SettingsIcon size={20} /></button>
            </div>
          </div>
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center bg-gray-800/80 rounded-xl border border-gray-700 p-1">
               <button onClick={() => changeMonth(-1)} className="p-1.5 text-gray-400 hover:text-white hover:bg-gray-700 rounded-lg"><ChevronLeft size={18} /></button>
               <div className="px-3 text-sm font-bold text-gray-100 min-w-[100px] text-center">{currentDate.toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}</div>
               <button onClick={() => changeMonth(1)} className="p-1.5 text-gray-400 hover:text-white hover:bg-gray-700 rounded-lg"><ChevronRight size={18} /></button>
            </div>
            <div className="flex bg-gray-800/80 rounded-xl p-1 border border-gray-700">
                <button onClick={() => setViewMode('LIST')} className={`p-1.5 rounded-lg ${viewMode === 'LIST' ? 'bg-gray-600 text-white' : 'text-gray-500 hover:text-gray-300'}`}><List size={18} /></button>
                <button onClick={() => setViewMode('CALENDAR')} className={`p-1.5 rounded-lg ${viewMode === 'CALENDAR' ? 'bg-gray-600 text-white' : 'text-gray-500 hover:text-gray-300'}`}><CalendarIcon size={18} /></button>
                <button onClick={() => setViewMode('CHART')} className={`p-1.5 rounded-lg ${viewMode === 'CHART' ? 'bg-gray-600 text-white' : 'text-gray-500 hover:text-gray-300'}`}><BarChart3 size={18} /></button>
            </div>
          </div>
          <div className="mt-4 relative">
            <button 
                onMouseDown={() => setShowTotalBalance(true)}
                onMouseUp={() => setShowTotalBalance(false)}
                onMouseLeave={() => setShowTotalBalance(false)}
                onTouchStart={() => setShowTotalBalance(true)}
                onTouchEnd={() => setShowTotalBalance(false)}
                className={`w-full h-14 rounded-2xl border transition-all duration-200 flex items-center justify-center gap-2 select-none touch-manipulation relative overflow-hidden group ${showTotalBalance ? 'bg-indigo-600 border-indigo-500' : 'bg-gray-900 border-gray-700'}`}
            >
                {showTotalBalance ? (
                    <div className="animate-in zoom-in duration-75 flex items-center justify-center"><span className="text-2xl font-bold font-mono text-white tracking-tight">{totalBalance.toLocaleString('en-IN', { style: 'currency', currency: 'INR' })}</span></div>
                ) : (
                    <div className="flex items-center gap-2 text-gray-400 group-hover:text-gray-200"><div className="p-1.5 bg-gray-800 rounded-full border border-gray-700"><Lock size={14} /></div><span className="text-xs font-bold tracking-widest uppercase">Hold to view Balance</span></div>
                )}
            </button>
          </div>
          <div className="grid grid-cols-2 gap-3 mt-4">
             <div className="bg-gray-800/40 rounded-xl p-3 border border-gray-800 relative overflow-hidden group">
                <p className="text-xs text-rose-400 font-bold uppercase tracking-wider mb-1 relative z-10">Expense</p>
                <p className="text-xl font-bold text-white relative z-10">₹{monthlyStats.expense.toLocaleString('en-IN')}</p>
             </div>
             <div className="bg-gray-800/40 rounded-xl p-3 border border-gray-800 relative overflow-hidden group">
                <p className="text-xs text-emerald-400 font-bold uppercase tracking-wider mb-1 relative z-10">Income</p>
                <p className="text-xl font-bold text-white relative z-10">₹{monthlyStats.income.toLocaleString('en-IN')}</p>
             </div>
          </div>
        </div>
      </header>
      <main className="flex-1 overflow-y-auto p-4 pb-32 scroll-smooth">
        {cutoffDate && (<div className="mb-4 bg-indigo-900/20 border border-indigo-500/30 rounded-xl p-3 flex items-center gap-3"><div className="p-1.5 bg-indigo-500/20 rounded-full text-indigo-400"><Sparkles size={16} /></div><div><p className="text-sm font-bold text-indigo-300">Started Fresh</p><p className="text-xs text-indigo-400/70">Previous data is hidden but safe in Sheets.</p></div></div>)}
        {viewMode === 'LIST' && (
            <>
                <div className="relative mb-4"><Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={16} /><input type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search..." className="w-full bg-gray-900 border border-gray-800 rounded-xl pl-10 pr-4 py-3 text-sm text-white focus:border-indigo-500 outline-none" /></div>
                <div className="space-y-3 animate-fade-in">
                    {filteredHistory.length === 0 ? (
                        <div className="text-center py-20 opacity-50 flex flex-col items-center"><div className="bg-gray-800 p-4 rounded-full mb-3"><Search className="text-gray-500" size={24}/></div><p className="text-gray-400 font-medium">No transactions found.</p></div>
                    ) : (
                        filteredHistory.map((tx) => (
                        <div key={tx.id} className="bg-gray-900/50 p-4 rounded-2xl border border-gray-800 flex items-center justify-between hover:bg-gray-800 transition-colors group">
                            <div className="flex items-center gap-4">
                            <div className={`p-3 rounded-xl ${tx.type === 'DEBIT' ? 'bg-rose-500/10 text-rose-500' : 'bg-emerald-500/10 text-emerald-500'}`}>{tx.type === 'DEBIT' ? <ArrowDownCircle size={20} /> : <ArrowUpCircle size={20} />}</div>
                            <div><p className="font-bold text-gray-200">{tx.category}</p><p className="text-xs text-gray-500 font-mono mt-0.5">{new Date(tx.date).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric' })}</p></div>
                            </div>
                            <span className={`font-bold text-lg font-mono ${tx.type === 'DEBIT' ? 'text-rose-400' : 'text-emerald-400'}`}>{tx.type === 'DEBIT' ? '-' : '+'}{tx.amount.toLocaleString('en-IN')}</span>
                        </div>
                        ))
                    )}
                </div>
            </>
        )}
        {viewMode === 'CALENDAR' && (
            <div className="space-y-6">
                <CalendarView currentDate={currentDate} events={validHistory} onDateSelect={setSelectedCalendarDate} selectedDate={selectedCalendarDate}/>
                {selectedCalendarDate && (
                    <div className="animate-in slide-in-from-bottom-5">
                        <div className="flex items-center justify-between mb-3 px-1"><h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider">{selectedCalendarDate.toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}</h3><button onClick={() => setSelectedCalendarDate(null)} className="text-gray-500 hover:text-white"><X size={16}/></button></div>
                        <div className="space-y-3">{calendarDayTransactions.length > 0 ? calendarDayTransactions.map(tx => (<div key={tx.id} className="bg-gray-800 p-3 rounded-xl border border-gray-700 flex justify-between items-center"><div className="flex items-center gap-3"><div className={`w-2 h-2 rounded-full ${tx.type === 'DEBIT' ? 'bg-rose-500' : 'bg-emerald-500'}`}></div><span className="text-gray-200 font-medium">{tx.category}</span></div><span className={`font-bold font-mono ${tx.type === 'DEBIT' ? 'text-rose-400' : 'text-emerald-400'}`}>{tx.amount.toLocaleString('en-IN')}</span></div>)) : (<div className="text-center py-8 text-gray-500 bg-gray-800/50 rounded-xl border border-gray-800 border-dashed">No activity</div>)}</div>
                    </div>
                )}
            </div>
        )}
        {viewMode === 'CHART' && (<Dashboard expenses={filteredHistory} />)}
      </main>
      {showUndoToast && (
          <div className="fixed bottom-24 left-1/2 -translate-x-1/2 z-50 w-auto animate-in slide-in-from-bottom-5 fade-in duration-300">
              <div className="bg-gray-800 border border-gray-700 shadow-2xl rounded-xl p-3 pr-4 flex items-center gap-4">
                  <span className="text-sm font-bold text-white flex items-center gap-2"><CheckCircle size={16} className="text-emerald-500" /> Added</span>
                  <div className="h-6 w-px bg-gray-700"></div>
                  <button onClick={handleUndoLastTransaction} className="flex items-center gap-1.5 text-sm font-bold text-rose-400 hover:text-rose-300 px-3 py-1.5"><Undo2 size={16} /> Undo</button>
              </div>
          </div>
      )}
      <div className="glass-panel border-t border-gray-800 p-4 z-30 pb-6">
        <div className="max-w-md mx-auto flex gap-4">
          <button onClick={() => setActiveEntryType('CREDIT')} className="flex-1 btn-3d btn-3d-green text-white h-14 rounded-2xl flex items-center justify-center gap-2 font-bold text-lg"><Plus size={24} strokeWidth={3} /> Income</button>
          <button onClick={() => setActiveEntryType('DEBIT')} className="flex-1 btn-3d btn-3d-red text-white h-14 rounded-2xl flex items-center justify-center gap-2 font-bold text-lg"><Minus size={24} strokeWidth={3} /> Expense</button>
        </div>
      </div>
      <ChatWindow history={validHistory} onAddTransaction={handleSubmitTransaction} onReset={handleSoftReset} />
      {activeEntryType && (<SimpleEntry type={activeEntryType} onClose={() => setActiveEntryType(null)} onSubmit={handleSubmitTransaction} />)}
      {showSettings && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-0 overflow-y-auto animate-in fade-in">
             <div className="min-h-screen w-full flex items-center justify-center p-4">
                 <div className="bg-gray-900 w-full max-w-2xl rounded-3xl shadow-2xl relative border border-gray-800">
                     <button onClick={() => setShowSettings(false)} className="absolute top-4 right-4 p-2 hover:bg-gray-800 rounded-full text-gray-500 hover:text-white transition-colors z-10"><X size={24} /></button>
                     <div className="max-h-[85vh] overflow-y-auto"><Settings config={config} onSave={handleSaveConfig} onDataCleared={handleDataCleared} /></div>
                 </div>
             </div>
        </div>
      )}
    </div>
  );
};
export default App;